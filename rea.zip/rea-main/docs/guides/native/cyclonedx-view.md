# CycloneDX dependencies

`inspect_analysis_view` with `{ "kind": "cyclonedx" }` projects one retained
`inspect_go_binary` or `inspect_rust_binary` Evidence record into a CycloneDX
1.6 JSON document. It reads no target bytes and does not repeat the analysis.

The same Evidence produces the same bytes. The document has no timestamp.
`serialNumber` is a UUID derived from the parent Evidence digest.

`metadata.component` is the binary file. Its name is the file name, and its
hash is the artifact SHA-256. `metadata.tools` names the provider recorded in
the parent Evidence, the reader that observed these facts, so the document
depends only on its parent and not on the REA build that projects it.

The Go and Rust readers record `artifact.file_name` using the source host's
filesystem path rules. A later projection uses that recorded name, including
literal backslashes in a POSIX file name and mixed separators in a Windows
path. Older Evidence without this field remains readable: the component name
keeps the full recorded artifact path, and `rea:unknown` explains that its file
name is unknown. The path and SHA-256 identity are preserved in both cases.

That hash covers the whole file, and the inventory of a universal Mach-O covers
one slice of it. For a slice, `metadata.component.properties` names the selection
with `rea:macho:architecture`, `rea:macho:container`, `rea:macho:offset`,
`rea:macho:byte_length`, `rea:macho:cpu_type`, `rea:macho:cpu_subtype` and
`rea:macho:container_table_sha256`.

Components use Package URLs:

- Go modules use `pkg:golang/<module path>@<version>`. Slashes in the module
  path stay separators. Other characters outside the URL unreserved set are
  percent-encoded. The namespace and name are lowercased. A Go `h1:` sum is
  a directory hash, so it is the property `rea:go:sum` and is not a `hashes`
  entry. When a replacement is a module path, the component is the replacement.
  `rea:go:original-path`, `rea:go:original-version` and `rea:go:original-sum`
  keep the replaced module as recorded, because a Package URL lowercases the
  path. `rea:go:original` is that module's Package URL, and it is absent when
  the path cannot name one. A local path, such as `./dep` or an absolute path,
  has no module identity. Neither does a malformed path, such as one with an
  empty, `.` or `..` segment. Such a component has no Package URL, its
  `bom-ref` is `go-module:<index>`, and the path stays unknown. A Go module
  with a single-segment name, such as `standalone`, keeps its recorded module
  name, version, and graph edges. It also uses a local `bom-ref` because the
  [Go Package URL type requires a namespace](https://github.com/package-url/purl-spec/blob/5e4dd947d9f535616124f1f870ef9c04f5846227/types/golang-definition.json).
- Rust crates from crates.io use `pkg:cargo/<name>@<version>`. A slash in a
  crate name is encoded. `pkg:cargo` resolves to crates.io, so a `local`, `git`
  or other source has no Package URL. Its `bom-ref` is `rust-package:<index>`,
  `rea:cargo:source` keeps the source, and the identity stays unknown. A
  package whose kind is `build` has `scope: excluded`. An omitted
  kind does not set `scope`. CycloneDX consumers assume `required` when
  `scope` is omitted, so `rea:cargo:kind` with the value `omitted` and a
  document limitation record that the kind is unknown.

Rust dependency entries follow the embedded package indices, including a
recorded self-edge. When the embedded record names a root package, a dependency
entry from `metadata.component` to that package and the document property
`rea:cargo:root` give its `bom-ref`. A record without a root adds neither, so
the binary's own package stays unknown. Go build information has no module graph, so the document
records only edges from the main module to each module and sets `rea:go:graph`
to `main-module-edges`. A decoded main module also gets a dependency entry from
`metadata.component` and the document property `rea:go:main` with its
`bom-ref`, including when an incomplete module record leaves out the main
module's own dependency list. Without a decoded main module, neither is added.

`compositions` is `incomplete` when the producer reports partial coverage and
`unknown` otherwise. It is never `complete`. An embedded record does not
establish that nothing else is linked.

The view keeps artifact identity, the parent Evidence id, a view digest,
coverage, limitations and the unknowns carried by the parent. Unknowns and
limitations are also document properties named `rea:unknown` and
`rea:limitation`, next to `rea:evidence_id`, so an extracted document keeps
them.
The document does not page. A document larger than 1,048,576 bytes is refused.
Recorded fields are counted before any Package URL or document is built, so
the refusal diagnostics record `document_bytes` as exact or a lower bound, as
`document_bytes_bound` states. The fixed allowance records its byte ceiling,
and the recovery names `export_evidence_bundle`.

One parent produces one document. Several parents are not merged, and SPDX is
not produced.

```bash
rea inspect-go-binary /absolute/path/to/program --json > go-evidence.json
cat > cyclonedx-view.json <<'JSON'
{"source":{"kind":"evidence-file","path":"go-evidence.json"},"view":{"kind":"cyclonedx"}}
JSON
rea inspect-analysis-view cyclonedx-view.json --json | jq '.normalized_result.document' > sbom.cdx.json
```

The same request works for Rust Evidence from `inspect-rust-binary`. MCP uses
`inspect_analysis_view` with a retained, inline or file source.
