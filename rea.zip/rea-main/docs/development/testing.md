# Testing REA

Use this guide when choosing coverage, pruning tests, or running a verification
lane. Start with the commands below; use [real-toolchain lanes](#real-toolchain-verification-lanes)
for engine prerequisites and [client verification](client-verification.md) for
installed-client and agent runs.

Historical verification records may refer to `experiments/analysis-efficiency`.
Those experiment scripts are available in the [archived source tree](https://github.com/morluto/rea/tree/a2e2c29b59e8775b0e6aedb09a9eb16adf32646b/experiments/analysis-efficiency);
they are not included in current checkouts. The retained [test support](https://github.com/morluto/rea/blob/main/tests/support/analysis-efficiency/README.md)
contains deterministic checkers and fixtures. The [allocation report](../verification/analysis-efficiency/mcp-integer-allocation.md)
and its original receipt JSON remain documentation, checked by the report producer.

## Developer commands

Use source feedback while editing, explicit boundary checks for the changed
behavior, and complete CI evidence before merging.

On Windows, PowerShell may resolve `npm` to `npm.ps1` and refuse to load it
when script execution is restricted. If the error names `npm.ps1`, use the
installed `npm.cmd` launcher for the same commands, for example:

```powershell
npm.cmd run test:local -- src/config.test.ts
npm.cmd run check:fast
```

This selects npm's Windows command launcher without changing PowerShell's
execution policy. Keep the repository's pinned Node.js and npm versions on
`PATH`; this does not install a toolchain or fix missing dependencies. Scripts
that invoke PowerShell themselves remain subject to their own policy checks.

| Command                           | Scope                                                                                                                   |
| --------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| `npm run test:local`              | Dirty source tests via the import graph, without build; explicit source paths run regardless of Git status              |
| `npm run test:focused -- PATH...` | Exact existing test files; compiled boundaries build first, and unmatched paths fail                                    |
| `npm run test:changed`            | Source tests affected since the merge base with `origin/main`, including committed and dirty changes                    |
| `npm run test:fast`               | All domain, service, adapter, composition, conformance, and evaluation tests without build                              |
| `npm run test:boundary`           | Boundary, CLI boundary, MCP boundary, process boundary, and process-global projects                                     |
| `npm run test:mcp`                | MCP boundary project                                                                                                    |
| `npm run test:acceptance`         | Complete compiled CLI and MCP acceptance workflows                                                                      |
| `npm run test:python`             | LLDB and mitmproxy producer contracts plus analysis-efficiency checks; no real debugger or proxy required               |
| `npm run test:watch`              | Dirty source tests in watch mode, without build                                                                         |
| `npm run test:watch:all`          | Changed tests from every project; builds at startup, so rebuild after production edits before relying on compiled tests |
| `npm run check:fast`              | Cached typecheck and lint, then the architecture guards and their counted baselines                                     |
| `npm run check:changed`           | Cached typecheck/lint and branch-related source feedback                                                                |
| `npm run check:pr`                | Opt-in deterministic test suite and generated-file checks                                                               |
| `npm run docs:check`              | Generated-document validation and fresh onboarding example consistency checks                                           |
| `npm run docs:build`              | Generate and build the VitePress site for local preview                                                                 |
| `npm run verify:docs:routes`      | Build the VitePress site and verify rendered local routes, anchors, images, and physical edit targets                   |

`typecheck` also checks the JavaScript verification scripts listed in
`tsconfig.scripts.json` (`checkJs`, with the main compiler options). Those
scripts import built modules through the package-private `#dist/*` alias, which
Node resolves to `./dist/*` at run time and the check resolves to `./src/*`, so a
domain signature change that breaks a listed script fails `check:fast` without a
build. To add a script, switch its `../dist/` imports and those of the local
modules it loads to `#dist/`, add it to the list, and fix what the check
reports with JSDoc types. Name tool results with the
`scripts/lib/mcp-verifier-results.mjs` typedefs (`ToolName`,
`VerifierOperationResult<N>`) so a result reads with its named contract's
type. `tests/support/analysis-efficiency/android-mapping-retention.mjs` stays
outside the check: it imports `dist` modules by path from a caller-selected
checkout at run time, so no import in this tree names their types.

The general source suite above runs on Linux in CI, and Windows CI runs a
curated lane ([Native platform baseline in CI](#native-platform-baseline-in-ci)).
A Windows source checkout can fail source tests for reasons unrelated to the
change, such as POSIX fixture paths, `#!/bin/sh` tool stubs, or POSIX rename
semantics. Compare failures against the base revision, or run the suite on
Linux or WSL, before attributing them to a change. See `CONTRIBUTING.md` →
Windows source checkouts.

The CI documentation lane runs `docs:check` and `verify:docs:routes` when the
change classifier selects documentation or its producing inputs. Follow the
[documentation authoring checks](documentation.md#generated-ownership-and-checks)
and verify external URLs and GitHub-rendered headings separately when editing
them.

For example:

```bash
npm run test:local -- src/config.test.ts
npm run test:focused -- tests/acceptance/applications/runtime.test.ts
npm run test:changed -- --base origin/main
npm run test:changed -- --dry-run
```

`test:focused` accepts exact repository-relative test file paths. Source-only
paths do not build; boundary, acceptance, process-global, or unfamiliar `tests/`
paths build conservatively. Tests use Vitest concurrency and isolated
workspaces; commands do not hold a broad test lock. Build and documentation
writers retain checkout-local locks for their shared output files. Explicit
selections do not use `--changed` or permit zero-test success.
The dry-run option reports the chosen merge base, scope and build prerequisite
without executing tests or building. A missing Git base reports how to fetch
it or select another revision.

Source typechecking needs no compiled runtime or generated test metadata.
Typecheck, runtime compilation, and Frida binding verification share
`scripts/run-typescript.mjs`. The pinned tsrs package supplies Linux x64/arm64
(GNU and musl) and macOS arm64 compilers. Windows and other unsupported hosts
retain the existing stable official TypeScript compiler. Its upstream version
can differ from tsrs, so both compiler tasks hash the selected package and version
through `scripts/run-turbo.mjs` before cache lookup. Outputs from different
compilers occupy different cache entries. Repository npm scripts and focused-test
preparation use that entrypoint; a raw Turbo compiler task without matching
identity fails instead of publishing an ambiguous successful cache entry.
A missing binary on a supported host also fails without silently falling back.

Development verifiers load their shared command, terminal and file owners from
source using Node's in-process TypeScript transformation. A single process-lifetime
loader handles this checkout's `src/` and `scripts/lib/` graphs, resolving missing
relative `.js`/`.mjs` imports to their `.ts`/`.mts` source. Existing JavaScript and
modules outside those roots keep native resolution and failures. Node's module
cache shares source identities within the verifier process; transformed output
is not cached across Node versions. Restart the verifier after source edits.
This avoids a cold-cache compiler subprocess surviving command cleanup; the
live process-lineage checks remain required.

The Rust compiler defaults to at most two checker threads. For `--noEmit` checks,
`--maxMemory 3G` also sets a soft memory target; emit builds do not use that target.
Explicit compiler arguments can override the defaults. These controls do not
impose a process-family memory limit. Termux's explicit build, Stryker's compiler
API dependency, and independent fixture compiler oracles keep their existing
TypeScript versions.

`npm run build:cached` compiles the CLI/MCP runtime and its packaged skill.
The build also records `dist/mcp-catalog.json` (compact inputs) from the
canonical SDK registrations and binds it to the runtime with its SHA-256
digest. Target-free stdio MCP startup with the default catalog and output
profiles serves its schemas without constructing analysis validators, including
when `REA_MCP_TOOL_FAMILIES` limits which tools and prompts are advertised.
The first tool or guided-workflow request materializes the canonical runtime
on that same SDK server. It preserves the advertised schemas throughout
materialization. Initial-target, HTTP, compact output, and family-scoped hot/cold
startup use eager composition, as do source runs without recorded artifacts.
Compare memory both after discovery and after a completed request; report
diagnostic GC separately from normal resident memory.

Turbo's strict task environment preserves caller-selected `GOMAXPROCS`,
`GOMEMLIMIT`, and `UV_THREADPOOL_SIZE` for resource-constrained builds and
checks. These execution controls do not change artifact content, so changing
their values retains cache reuse. They control individual runtimes; monitor
the complete process family separately when enforcing a total memory budget.
`npm run test:prepare` also generates the product catalog and portable managed
evidence used by the complete suite. Focused tests prepare those extra outputs
only when their selected files consume them.
Documentation generation and managed conformance run through their separate
`docs:generate` and `evidence:generate` task graphs.

Changed selection can miss runtime registration, generated data, shell
entrypoints, bridges, or other relationships absent from the import graph.
An empty changed selection means no tests were selected, not verified
correctness. Select relevant boundary files and real-provider lanes explicitly.
Source projects also contain large capacity regressions; `test:fast` promises
no compiled-runtime prerequisite, not a fixed time budget.

`npm run lint` prints errors and a warning summary; `npm run jscpd` prints
duplication statistics. Complete reports remain in `.cache/static-checks/`.
The fast gate uploads them as `static-check-reports`. Full qualification
uploads duplication diagnostics from the deep job as
`static-deep-check-reports`, including after that gate fails.
Task-graph recording runs `check:ci:fast:tasks` and `check:ci:deep:tasks`
without the artifacts lock, so it can record hashes while `check:pr` or
`check:test` already holds that lock. The CI jobs still run the locked
`check:ci:fast` and `check:ci:deep` commands.
Use `npm run lint:details` or `npm run jscpd:details` for all console diagnostics.
Both duplicate commands scan production and test code using the limit in
[`.jscpd.json`](https://github.com/morluto/rea/blob/main/.jscpd.json).
The summary commands preserve checker failures and restore reports from cached
static tasks. Both lint caches include the website, documentation configuration,
and experiment code scanned by the checker; a regression compares the actual
lint inventory with Turbo's resolved inputs.

Static checks locate candidates; they do not establish semantic ownership.
`jscpd` finds token clones, and Knip counts test references as uses. Module
boundaries and architecture guards enforce their declared import and source
rules. Passing them does not prove that two parsers agree, a wrapper is still
needed at runtime, or cleanup has one owner.

The lint gate treats `no-async-promise-executor`, `no-unreachable`, and
`no-unsafe-optional-chaining` as errors. These catch lost async executor failures,
dead code, and unsafe uses of optional-chain results. `no-unsafe-finally` remains
a warning because cleanup paths can deliberately throw aggregated failures;
review whether they preserve the primary failure. Two local rules
cover narrower observed failures: `rea/no-buffer-deep-equality` flags Vitest
deep comparisons of Buffers from recognized constructors and file reads,
including simple `const` aliases; `rea/cancellation-cause` requires an explicit
cause when a directly checked caller `AbortSignal` is converted to an
`AnalysisCancelledError`. The rules do not infer arbitrary Buffer types,
follow indirect cancellation helpers, or prove that an explicit cause equals
the caller's reason. Keep focused boundary and lifecycle tests for those facts.

Build a cancellation with `cancelledBy` from `src/domain/analysisErrorCore.ts`.
Its reason argument is required: an aborted `AbortSignal`, an earlier
`AnalysisCancelledError`, a `carriedReason(...)` recovered from an inner
failure, or an `OwnerCancellation` when REA itself closed the work's owner. The
architecture guard rejects a direct `new AnalysisCancelledError(` outside that
module. No file is allowed one, so this guard has no baseline file; a guard
without one allows zero copies. Other counted guards still list the files that
keep copies, with their counts; a file may not exceed its count, and after
removing copies run `node scripts/verify/architecture-guards.mjs --shrink-baselines`
to lower it. Each counted guard keeps its baseline in its own
`scripts/verify/baselines/<guard-key>.json`, with paths sorted by code unit, so
changes to different guards never edit the same file. Resolve a conflict in one
of these files by keeping both sides' entries (the higher count where they
differ) and rerunning `--shrink-baselines`.

`rea/no-evidence-json-preadmission` rejects direct generic JSON parses in
`createEvidence` payload expressions; it does not analyze intermediate values.
`rea/no-positional-tool-contract` rejects catalog indices used to select
operation names, schemas or types; display-only selection remains allowed.
`rea/no-fixture-root-cleanup` follows `const` fixture-root aliases into teardown
deletion; mutable bindings and mixed root arrays remain outside its scope.
`rea/project-wait-deadline` resolves Vitest's `vi` and `expect` bindings,
including aliases and namespace imports; a shadowed local or a fixture method
with the same name is not reported.

`rea/no-shared-module-mock` resolves Vitest import bindings before rejecting
module mocks in projects without per-file isolation. The test-project definitions
own isolation for Vitest and lint; the executable gate checks the resolved policy
and runs the same collector. Aliases and namespace imports count; comments,
shadowed locals, ordinary methods and `spyOn` do not. Negative CLI probes use an
external temporary project so concurrent repository checks cannot discover them.

Focused `.only` declarations, broken assertion promise chains, and unused disable
directives are errors. `vitest/valid-expect` warns (`maxArgs: 2`) because valid stored and
collected assertions can be awaited later. `import/no-duplicates` warns with
`preferInline: false`.

`no-useless-escape` keeps intentional `\-` regex escapes. Source regexes need
no escaping for clients: the presentation re-emits every advertised pattern in
the portable grammar (`src/contracts/portablePattern.ts`).

Fast lint stays syntax-based. `npm run lint:typed` runs serially with pinned
`oxlint-tsgolint` 7.0.2005 and records native plus typed diagnostics in
`.cache/static-checks/typed-oxlint.json`. Production `src` treats
`no-misused-promises` as an error; tests/fixtures warn. `no-floating-promises` is
an error throughout the lint inventory. `return-await` is an error in
error-handling scopes so asynchronous completion stays inside its catch or
cleanup boundary. Exhaustiveness is an error when a union member has neither a
case nor a default. Intentional defaults count as handling the remaining union;
new members covered by those defaults therefore require behavioral review.

Two HTTP/3 source-test files allow the runner-owned `node:test` registration API;
ordinary unowned promises in those files still fail. The authored code-split
recovery input is exempt from floating-promise policy because it is analysis
input, rather than application orchestration. Preserve framework-owned callbacks
such as an awaited `Promise.finally`; inspect the actual completion owner before
changing a callback solely to satisfy its declared `void` return type.

`npm run knip:production` writes advisory candidates to
`.cache/static-checks/production-reachability.json`; execution/report errors fail.
Ordinary Knip remains. `check`, `check:pr`, and `check:ci:deep` run reachability
then typed lint sequentially after cached work. Typed lint builds the project
type graph and stays separate from fast feedback. Its default Go settings are
`GOMAXPROCS=1` and `GOMEMLIMIT=1024MiB`; caller-selected settings take precedence.
One Go worker reuses checker caches across the file queue without changing the
file inventory or TypeScript project scope. The Go memory target is soft and
does not cap the complete process family's memory; measure the full invocation
when enforcing a host budget.

Routine iterations and rebases need focused regressions and relevant checks.
Follow the [contributor checks](https://github.com/morluto/rea/blob/main/CONTRIBUTING.md#development-feedback-and-pr-verification)
before handing off a PR. Use `check:pr` for broad changes or CI diagnosis.
Architecture guards run in `check`, `check:fast`, and `check:ci:deep`.
The standalone test-discovery check runs in `check:ci:deep`.

Vitest projects use up to two workers, bounded by host parallelism. GitHub
Actions jobs own their runner and use up to four; see
[test deadlines](#developer-commands) for how deadlines scale there.
`process-boundary` runs later with serial files because process-tree sampling
shares host resources. Acceptance and process-global cases use isolated forks
without serial scheduling. Pure domain/service, composition, conformance,
evaluation, CLI boundary, and MCP boundary projects share module graphs. Their
tests avoid process-global state and keep resource cleanup test-scoped. Source
projects run those shared graphs in forked workers, so each worker owns its own
heap and no single process holds the whole lane. Each
MCP session still owns its resources, and CLI cases retain fresh command
instances or subprocesses. Fixtures using `vi.mock` or `vi.doMock` need an
isolated project. CLI/MCP fixtures normally live in `tests/process-global/`.
When a path must stay, assign it explicitly in `scripts/lib/test-projects.mjs`,
exclude it from its shared owner, and preserve its source/built group.
Product catalog verification stays with the
isolated filesystem boundary tests because it loads both source and compiled
module graphs. Adapter, other boundary, acceptance, and process-global projects
retain per-file isolation. See `vitest.config.ts` for current settings.

Inject producer faults through scoped dependencies in shared workers: a module
mock cannot replace a consumer that was imported earlier. Check these tests
with the consumer preloaded as well as alone. For simulated protocol traces,
use an acknowledged event barrier before asserting complete observations;
a zero-duration capture does not guarantee queued events have arrived.

Place faults at the semantic boundary under test: the selected read, EOF, hash
completion, or cleanup attempt. Global call ordinals can shift during setup or
refactoring without reaching that phase. For controlled asynchronous gates, use
`awaitAcknowledgement` from `tests/fixtures/lifecycleAcknowledgement.ts` to race
the acknowledgement against triggering-operation settlement and a bounded
deadline. Register release gates before launch, then release and join launched
work in `finally` before restoring mocks, even when the barrier fails.

Focused contract tests should import the named contract family they exercise;
reserve the full tool catalog for catalog-wide assertions. Resolve contracts by
operation name rather than array position.

Check advertised schemas after SDK conversion for every supported schema
profile. Meta-schema validity does not establish client acceptance or useful
rendered declarations. `src/contracts/advertisedDialect.ts` owns the portable
advertised dialect: the keyword allowlist, size and depth limits, and the regex
grammar that compiles in V8, Python, RE2 and Rust. `advertisedDialect.test.ts`
lists every output and catalog profile combination and requires zero dialect
violations; there is no baseline, so a construct outside the dialect fails the
test by name. The packaged catalog check applies the same rule to the default
profiles.
Advertised patterns, input and output, are enforced at zero:
`portablePattern.ts` re-emits each one exactly, widens it, or omits it, and the
presentation drops any enclosing `not` or `if` and turns `oneOf` into `anyOf`
when a pattern widens. `portablePattern.test.ts` pins the same acceptance of
BMP strings in V8's plain, `u` and `v` modes. Python, Go and Rust read code
points as `u` does; Python's `$` also matches before a final newline, which
only widens. A client compiling without `u` may still reject one astral
character where a wildcard, shorthand or negated class must match it (for
example `^[\S]$`); `PortablePatternProjection` documents this accepted
limitation. Keep canonical rejection checks separate from the
intentionally reduced compact advertisement, and probe actual client renderers
when changing schema representations.

The grammar rules are not evidence that an engine accepts a pattern.
`npm run verify:advertised-schemas` lists tools from the built package's stdio
entry in every input, output and catalog profile, then compiles each distinct
advertised regular expression (`pattern` values and `patternProperties` keys)
with the engines clients run: V8 (plain, `u`, `v`), Go `regexp` (RE2), C++
RE2, Python `re`, and Rust `regex` and `fancy-regex` through the Rust
`jsonschema` crate. A refusal names the engine, its error, and each tool,
schema path and profile that advertises the pattern. Go is the host
toolchain, run with `GOTOOLCHAIN=local` so it is never downloaded. The other
engines are pinned, hash-checked wheels listed in
`scripts/verify/advertised-schemas/requirements.txt`; nothing installs them on
a developer machine. To check them locally, install that file into a virtual
environment with `pip install --require-hashes -r` and set
`REA_SCHEMA_ENGINES_PYTHON` to its interpreter. A missing engine is reported
as not verified rather than passed; `REA_REQUIRE_SCHEMA_ENGINES=1` turns it
into a failure. CI's build job sets it after uploading the build, using the
runner's Go and a virtual environment cached by the requirements file's
digest, so every code change runs every engine. The pre-push hook does not
run the check, because it needs a current build. `--package-root=DIR` lists
an installed package instead of the checkout's build; the release guide uses
it to [check the qualified archive](releasing.md#check-the-packed-catalog-with-client-engines).

The same run compares the listings with the per-tool summaries in
`scripts/verify/advertised-schemas/tools/`: each file records one tool's
schema digest per input or output profile and the patterns its schemas
advertise. A difference fails the check and prints aggregated lines such as
`119 tool schemas gained pattern /…/`, so a change that reaches many tools at
once is visible in review, followed by the expected contents of every missing
or stale file. Commit those contents with the schema change, or regenerate
them with `npm run verify:advertised-schemas -- --update-summary`, which also
deletes the files of removed tools. A PR that adds a tool adds only its own
file, so PRs adding different tools do not conflict. Absolute local paths
advertise the host's pattern, so the summaries record the POSIX advertisement
and Windows hosts skip the comparison.

The same run builds a validator for every distinct advertised input and output
schema with the Rust `jsonschema` crate's defaults, which check the declared
draft's meta-schema and formats and compile every subschema, as a Rust client
using that crate does. `--complete` adds Python `jsonschema`'s
`check_schema`, which `jsonschema.validate` runs before validating a
structured result in Python clients; it takes several seconds, so CI runs it
only in full qualification. Ajv
strict mode is not part of the check: it rejects authoring constructs such as
unknown formats that no supported client has been seen to refuse, and Ajv's
default meta-schema validation already runs in the package verifier. Clients
whose validators cannot run here keep their documented rejections as rules in
`advertisedDialect.ts`, each citing its report: the keyword allowlist and type
rules encode Gemini's function-declaration subset, and the root-shape rule the
Anthropic and OpenAI function-calling root. OpenAI strict mode (`strict: true`)
is not covered: it requires every property to be required, which REA's
optional inputs do not meet, and REA does not claim strict-mode support.

The reused CLI boundary workers cap V8 old space at 512 MiB, with or without
coverage. Ordinary CI also exhausted the former 384 MiB budget after earlier
files loaded the shared source/contract graph, while later command registration
and schema/help rendering still needed transient allocation space. This is a
measured capacity control, not a suite-wide speedup claim. The worker count
remains bounded, and spawned REA processes retain their own heap settings.
Coverage enablement still controls instrumentation, test deadlines and coverage
thresholds; explicitly disabling it or selecting only a provider does not enable
instrumentation.

Vitest worker limits do not bound subprocesses launched within a test. Bound
those batches separately so repeated CLI validation cannot oversubscribe the
runner. Preserve simultaneous launches where concurrency is itself under test.

Coordinate expensive checks across agents sharing a host. If a test unexpectedly
consumes heavy CPU, stop its owned process family, retain its log and revision,
and profile a bounded representative case before retrying. Separate production
work from fixture generation, schema compilation, subprocess startup and cleanup.
Choose elapsed, CPU and process-family memory limits before the run; a worker
count or test timeout alone does not enforce those limits.

A test deadline turns a hang into a named failure; it is not a performance
assertion. `vitest.config.ts` applies the deadlines in
`tests/support/testDeadlines.ts` per project: 30 seconds for source projects
and 120 seconds for built projects, with hooks sharing their project's
deadline. Coverage doubles every deadline, and so does hosted CI, where
CPU-bound cases share every core with other workers and their subprocesses.
Do not pass a per-test timeout to fit a slow host. A child run through a
test process registry (`processTest`, `cli.run`, or `createTestProcessRegistry`)
gets the running test's remaining deadline less a reporting reserve, so a hung
child fails with its captured output. Pass `timeoutMs` only when the child's deadline is itself under test. Tag a bounded workload that needs longer with
`{ tags: ["long-running"] }`, or a whole file with
`// @module-tag long-running`. Assert elapsed time explicitly when speed is the
behavior under test. Derive an explicit deadline only when a test must outlive
an operation deadline whose diagnostics it checks.

Waits follow the same policy; Vitest's one-second `expect.poll` and
`vi.waitFor` defaults assume a host's speed. A wait may take as long as its
test may run, less the reporting reserve: projects configure `expect.poll`
that way, and `waitFor` from `tests/support/testWait.ts` replaces `vi.waitFor`.
Fixture waits such as `awaitAcknowledgement` default to the same deadline.
`expect.poll` keeps its project's budget in a `long-running` test, while
`waitFor` follows the deadline the tag applies.
`rea/project-wait-deadline` rejects `vi.waitFor` and explicit poll timeouts. When promptness is the behavior under test, such as
cancellation that must preempt a slower production deadline, a wait timeout is
not its oracle: order the condition before releasing the gate that would
otherwise satisfy it, or compare elapsed time with the deadline it must beat.

Keep capacity fixtures intact when diagnosing a test failure. For byte equality
of large buffers, use `Buffer.equals` or `Buffer.compare`; a generic structural
diff can allocate far more than the production operation.

Remove demonstrated repeated work while preserving distinct assertions and
resource ownership. Share immutable fixture preparation where safe; keep fresh
sessions when lifecycle or concurrency is the behavior under test. Compare the
same completed workload before and after, report cache state and measurement
limits, and record interrupted runs separately from passes. Increasing a timeout
does not explain a CPU regression.

Build/documentation writers hold checkout-local output locks. Tests do not
hold a broad command lock; `check:pr` finishes tests before document validation.
Turbo caches deterministic preparation and static checks, but `test:run` always
executes. Repository files do not fully describe installed tool contents or host
state. A previous test pass therefore cannot replace current validation, even
when the source tree is unchanged. `check:pr` also runs the fast Python producer
suite. Fast CI runs it from the selected Python job after installing dependencies
and preparing the compiled runtime; full qualification runs it from the deep
static job. These producer tests do not establish real LLDB engine coverage.

Vitest's persistent compile cache remains disabled. The `cliTest` fixture shares
a temporary Node compile cache among its fresh CLI subprocesses. The worker
removes it after test-scoped processes finish. Explicit child environment
settings take precedence; children requesting `NODE_V8_COVERAGE` do not receive
the fixture cache. These subprocesses are outside aggregate Vitest coverage;
subprocess coverage attachment remains disabled. Cold-start import checks launch
independently without this fixture cache.

`analyzeJavaScriptDirectory` stdio MCP cases in one `cliTest` file share one
server and that compile cache. The first case pays startup; later cases reuse
the process. File teardown waits for startup still in flight, closes a server
registered during that wait, and does not open a server after close. A failed
handshake stays the caller error when its cleanup also fails, including a
rejection without a reason. That cleanup stays owned until a later close or
call releases it. Another server does not open while the cleanup remains, and
a cleanup that already succeeded is not run again. Pass
`mcpCall` when a case needs its own server, environment, or lifecycle. CLI
cases for that helper share one compiled CLI process per child environment.
The first case pays process startup; later cases reuse the loaded runtime.
The process restarts when the environment changes, after 32 commands, or when
the worker reports a resident set of at least 1 GiB. A fatal worker failure
or a broken session frame retires that process and waits for it to exit before
the next command starts.
In a `cliTest` file, `cli.run` uses that shared process when it reports the
command exactly as a fresh `rea` process would. Both run the same one-shot
owner (`src/cliOneShot.ts`), and the shared process presents the launcher's
entrypoint. A command starts a fresh process instead when it supplies stdin or
an explicit deadline, enters MCP or the MCP doctor (which the launcher routes
first), sets `NODE_OPTIONS`, or enables logging, which writes outside the
per-command capture. Pass `freshProcess: true` for process-level facts such as
startup, signals, or exit, and keep one fresh check beside reused cases where
dispatch itself is under test. `createTestCli` drivers always start a fresh
process. File teardown stops the shared CLI process, including startup still in
flight, and does not open another after close.
`exportedFunctionBindingsCli.test.ts` uses the shared compiled CLI session for
its file and compares its JSON command results with the MCP session. It selects
20-second startup and command deadlines; other callers retain their existing
deadline behavior. Retired processes stay owned until exit, block replacement,
and remain available for a later close to retry after failed termination.
Shared session cleanup closes stdin so the worker can release JavaScript
resources, waits the bounded grace, then escalates to SIGTERM and SIGKILL only
if needed. Confirmed exit succeeds; an unconfirmed exit reports cleanup failure.
When startup or a command fails and cleanup also fails, the reported aggregate
retains both failures and the original failure as its cause.
`applicationWorkflowCli.test.ts` keeps one compiled CLI process for its JSON
commands, including a non-zero status whose stdout is still a JSON document,
and closes that process after the file.

The Apple artifact verifier step shares a job-temporary bytecode cache among
its fresh CLI/MCP children via `REA_ARTIFACT_NODE_COMPILE_CACHE`. The artifact
helper maps this setting to child `NODE_COMPILE_CACHE`; npm, Turbo, and nested
Vitest runs do not inherit that setting. Explicit `NODE_COMPILE_CACHE` takes
precedence, and coverage collection or `NODE_DISABLE_COMPILE_CACHE=1` disables
the helper's cache. The cache is discarded with the CI job.

To evaluate persistent compile caching for repeated local runs, opt in for both
cold and warm measurements with an isolated cache:

```bash
NODE_COMPILE_CACHE=.cache/node-compile npm test
```

Do not report the warm result as a cold-suite improvement, and do not enable
the cache in coverage or benchmark CI without first showing that its
instrumentation remains equivalent.

### Verifier scripts

Compilers, linkers, `readelf`, and the REA CLI that a verifier starts go through
`createVerifierCommands()` in `scripts/lib/verify-commands.mjs`. The helper loads
`scripts/lib/verifier-command-owner.mts` and runs each command with
`runOwnedCommand` (`src/process/OwnedCommand.ts`). POSIX commands spawn through
`spawnOwnedProviderProcess` (`src/process/ProviderProcess.ts`); Windows commands
use the owned job from `scripts/lib/windows-owned-command.mjs`. Pass the
deadline to `exec` as `timeout` in milliseconds. An omitted timeout, or `0`,
keeps only caller cancellation. When the deadline elapses, owned cleanup kills
the process family: the POSIX process group and descendants that carry the
command run token, or the Windows job. Cleanup that does not confirm stays
on the verifier resource scope. `close()` aborts commands still running, and a
failed close stays registered for retry.

`createVerifierRun()` and `completeVerifierRun()` in
`scripts/lib/verifier-run.mjs` bracket the run. Call
`assertVerifierCleanupComplete` on the completed lineage. It accepts only status
`verified` with an empty descendant list, confirming that no owned process
survived. An `unavailable` lineage fails the assertion. Windows reports this
observation unavailable because the verifier has no retained Job Object lease
for it; provider jobs are verified by their native owners. A verified lineage
has checked every live descendant's `REA_PROCESS_RUN_ID`. An empty descendant
list means none were live during that observation. It does not prove that the
verifier never launched children earlier in the run. A PID is not ownership
proof.

Close the command owner before that assertion. If shutdown fails, retain the
diagnostic workspace. `scripts/verify-real-ghidra-ppc64.mjs` shares one command
owner for the compiler, `readelf`, and the CLI, closes it through
`workspaceFixture.closeEarly` before `completeVerifierRun`, and applies the same
lineage condition. The script retains the workspace when close fails, the
lineage is unverified, or the run fails, and releases the workspace only after
those checks pass.

Create the command owner before resolving or starting a tool, then start the
tool with that owner's `exec`. `execFile`, `spawn`, `execFileSync`, and
`promisify(execFile)` leave the process outside this owner. The example's
pre-workspace toolchain probe is `requireLaneToolchain`, which runs each probe
through `runOwnedCommand` so the tool starts under an owner. Scripts that still
call `execFile` directly are known debt. Migrate them separately; a new or
touched verifier uses these helpers.

## CodeQL production scope

[The production configuration](https://github.com/morluto/rea/blob/main/.github/codeql/production.yml) excludes
`tests/`, `scripts/fixtures/`, `*.test.*`, `*.fixture.*`, `test_*.py`, and `*_test.py` inputs
during extraction. It retains the default queries and the existing `local`
threat model. Production source, bridges, runtime scripts, installation and
release controllers, and Actions remain in scope for the configured languages.
Verification scripts remain included unless they match an explicit test path;
excluding the entire `scripts/` directory would hide shipped entrypoints.
The `paths` list retains repository-root traversal and explicitly includes
`docs/.vitepress/`, which JavaScript extraction otherwise skips as a hidden
directory. Keep directory entries here: the shared Python extractor does not
accept individual files as traversal roots. When changing this list, compare the
complete production file inventory as well as alert counts.
These exclusions do not change which behavioral tests CI executes. CodeQL's
JavaScript/TypeScript, Python, and Actions lanes do not add shell, Java, or Swift
analysis; their existing checks remain responsible for those languages.

[The production workflow](https://github.com/morluto/rea/blob/main/.github/workflows/codeql.yml) is inactive until a
repository administrator disables CodeQL **default setup** and sets the Actions
repository variable `REA_CODEQL_ADVANCED` to `true`. Disable default setup first:
it rejects advanced CodeQL uploads. Then enable the variable and manually run
**CodeQL production** on `main`; verify all three analyses complete before
relying on the new scope. While the variable is unset, the existing default
setup continues scanning. Adding the configuration file alone does not change
default setup in this user-owned repository.

Pull-request scans are cancelled when superseded, skip pure test/prose diffs via
`paths-ignore`, and select only the CodeQL languages (`javascript-typescript`,
`python`, `actions`) whose production inputs changed (failing closed to all
three languages on shared CodeQL configuration or unclassified paths). Active
scans on `main`, weekly schedules, and manual dispatches always analyze all
three languages so frequent pushes cannot prevent a complete baseline from being
uploaded. Cancelled runs skip the SARIF artifact upload when no report was
produced.

Each analysis uses two threads and a 4096 MiB CodeQL memory budget; language
jobs run one at a time. Complete SARIF reports are retained for seven days.
For a scope comparison, use the same source SHA, CodeQL bundle, default query
suite, and `local` threat model on both runs. Change only extraction paths, inspect
the extracted-file inventory and diagnostics, and retain both complete reports.
Alert counts do not establish a false-positive rate or a speedup. Report elapsed
time, CPU time, and process-family memory with their measurement limits.

## Choose verification for the change

`test:local` is fast source-level feedback. For the strongest practical
regression, prefer a real public CLI/MCP workflow, then production-boundary
integration, then a producer golden; use the table to select quick feedback and
claim-specific additional evidence. Provider-behavior claims require the
matching real-provider lane.

| Change or claim                           | Fast feedback                                                 | Claim-specific coverage                                      |
| ----------------------------------------- | ------------------------------------------------------------- | ------------------------------------------------------------ |
| Source semantics                          | `npm run test:local -- PATH...`                               | Relevant boundary cases when the behavior crosses a port     |
| CLI/MCP workflow                          | `npm run test:focused -- PATH...`                             | Actual public calls; an injected provider has limited scope  |
| Documentation or generated metadata       | `npm run docs:check`                                          | `npm run verify:docs:routes` for rendered routes and anchors |
| Engine adapter                            | Its real-provider lane below                                  | Host, version, target identity, and owned cleanup            |
| Client configuration or schema conversion | [Native client lane](client-verification.md)                  | Distinguish loopback models from live services               |
| Agent investigation quality               | [Agent evaluation](#agent-evaluation-and-conformance-records) | Review transcript and scenario-specific evidence             |

### Provider-backed workflow verification

For a new or changed provider-backed tool, select tests from the analyst's
question and the facts the contract claims, not from an upstream command list.
Use the existing workflow as a baseline and identify what the proposed tool
adds. Choose the relevant cases below; do not require every provider or a
Cartesian matrix when it would not change the claim.

When auditing existing tools, compare selected analyst workflows with the cases
their existing tests and real-provider lanes actually exercise. Run relevant
public workflows and focused checks; report untested scenarios rather than
inferring that a green test proves them or that no prior testing occurred. A fix
should add a regression for the demonstrated failure at its owning boundary and
affected consumer.

- Use a controlled target with independently known facts and a meaningful
  counterexample. Compare native provider output with the target or a
  format-aware oracle; a provider label, a mock, or another REA projection is
  not independent proof of the underlying fact.
- Exercise the affected public CLI/MCP workflow, including handoffs between
  calls. Assert the requested result, caller-selected inputs, source identity,
  evidence and coverage. Check that unavailable, partial and empty outcomes
  retain their different meanings across the producing and consuming boundaries.
- Where relevant, continue after a mixed success, failed request, cancellation
  or close/reopen. Verify the next supported recovery and preservation of prior
  results and resource ownership. Use the applicable lifecycle regressions below.
- For lookup failures, distinguish malformed input from a valid missing or
  ambiguous selector. Check the returned candidate and input identity, follow
  an actionable recovery where possible, and verify that an inventory miss is
  not presented as artifact-wide absence. Test schema-repair advice separately.
- Record the provider version, host, fixture, actual entrypoint, controlled
  faults and skipped or unavailable coverage. A simulated provider tests the
  integration boundary; a scripted sequence tests that sequence, not an agent's
  ability to discover it. Run the matching real-provider and agent lanes when
  their respective claims require them.

Every provider capability that `src/composition/capabilityDeclarations.ts`
binds to a provider needs an entry in
`tests/conformance/providerCapabilityCases.ts`. The entry is either a
CLI, MCP or acceptance test that exercises one of the capability's operations,
or an exemption that states why no such case exists.
`tests/conformance/providerCapabilityConformance.test.ts` iterates the
declarations, so a new capability fails the suite until it has one.

For prerequisite recovery, include a case where only the wrong alternative is
configured: Unblob cannot enable Binwalk inspection, and Binwalk cannot enable
Unblob extraction. Check the final readiness or capability output retains the
producer's repair instructions, including which launch environment must change.
When feasible, follow the advice and verify that the same operation now works.
Report unexecuted recovery steps explicitly.

Real-provider scripts that start compilers, linkers, readers, or the REA CLI
follow [Verifier scripts](#verifier-scripts).

### Checking installers and publisher downloads

When changing setup or investigating an install failure, check the stages affected
by the change:

1. **Does REA support installation on this host?** Check the distribution and CPU
   architecture, including an unsupported case. Recognizing RPM or DEB packages
   does not mean REA can install on every related distribution. Check prompts in
   a terminal and with redirected output; image builds cannot answer interactive
   prompts. `doctor` checks health; `setup` installs.
2. **Does the downloaded package match the publisher's metadata?** Record the
   release version, package format, URL and check date. Verify the signature and
   compare the launcher hash inside that package with the feed and installed
   launcher. Check each format you claim works: a passing DEB check says nothing
   about the RPM. Old fixtures cannot catch a newly published package mismatch.
   Test both an invalid signature and a valid signature with a mismatched launcher
   hash; setup must reject either before running the package manager.
3. **Can download failures be diagnosed?** Use REA's request headers and timeout.
   Check whether the setup result identifies the failed URL, HTTP status or
   timeout, and next action; report missing details. Use controlled failures for
   repeatable tests. A fast download on one network does not rule out a timeout
   elsewhere, and curl with different headers may get a different response.
4. **Does the installed provider run?** Check package-manager prerequisites and
   run doctor for the selected provider. For Linux Hopper, check Python and REA's
   private Xvfb display separately from package installation. Where relevant,
   test an unusable `/tmp/.X11-unix` and a blocked user/mount namespace fallback.
   Starting an extra X server does not test the display REA creates and cleans up.

For a full Linux Hopper setup check, run `npm run verify:setup:linux` on a clean
root Linux runner. Set `REA_VERIFY_SERVER_COMMAND` to the installed REA command.
This checks setup, doctor, CLI/MCP analysis and repeated setup on that runner.
Report which host, package format and steps you tested. Inspecting a Linux package
on macOS verifies package contents, not a working Linux installation.

## Test design and pruning

Prefer real public CLI/MCP workflows, then production-boundary integration,
then goldens captured from real producers. Keep module tests for distinct
failures or semantics that stronger workflows cannot reliably reproduce.
Paths, compiled imports, and suite names do not establish test depth.

Prune tests that mirror implementation details or duplicate a stronger claim.
Before deleting a distinct regression, identify the replacement scenario and
assertions. Preserve malformed formats, cancellation, cleanup, permissions,
capacity, target identity, and combinations with distinct interactions.
Trivial helper assertions need no replacement. Remove abandoned production
scaffolding only after checking runtime and verifier consumers, including
compiled imports.

Assert error codes, structured limit facts, source provenance, and observed
recovery behavior instead of freezing explanatory sentences or banning obsolete
phrases. Keep exact checks for protocol values, setting and parameter names,
caller data, and diagnostic provenance. To verify guidance delivery, compare the
consumer with the owning formatter or constant, alongside independent assertions
for the behavior and facts; shared text alone is not a correctness oracle.
Documentation wording belongs in review, not substring tests of source files.
When replacing prose assertions, verify that a harmless wording change passes
and an incorrect budget or lost fact still fails.

After an owner changes, move fault injection and event spies to the path the
production consumer actually uses, and assert that the intended boundary was
reached. Keep independent expectations from authored input, producer output, or
an external oracle; comparing two paths through the same replacement algorithm
does not preserve the old oracle. A negative probe inside a conditional or loop
must assert that it ran. Check that the facts compared actually exist: `every`
on an empty list, optional chaining, or comparing two missing values can pass
without exercising the behavior. For a suspicious assertion, use an isolated
controlled change that removes or alters the relevant fact; confirm the test
fails at the intended assertion, then restore the change and rerun it.

When a fixture generates JavaScript imports, serialize a `file:` URL as a
JavaScript string literal rather than embedding a native path. For relative-path
cases, choose the child process working directory deliberately and verify the
fixture produced a relative path; on Windows, paths on different drives can
produce an absolute result. Run the relevant platform lane when available and
report when it was not run.

Use representative scenarios rather than Cartesian matrices of equivalent
cases. Share setup without hiding inputs or expected evidence. For successful
`Result` values, throw the typed error before asserting the value; a preceding
`.ok` assertion adds no coverage. Protocol fixtures must reject unmodeled
commands and preserve actual producer reply shapes.

For comparison normalization, include a legitimate equivalent pair and a
distinct pair that would collapse if representation tags or scope were lost.
For learned identifiers, cover conflicting pairs and reused values in different
collections; mappings must remain one-to-one within their declared scope.

For coverage propagation, compare the same returned rows under complete and
incomplete examination. If a row exists on the left but is missing from a fully
examined compatible right inventory, removal can be established. If the right
side examined only eight of ten applicable records, or returns only one page,
the same missing row remains unknown unless separate evidence proves absence.
Assert the structured coverage and comparison status as well as the explanation.

For format compatibility, identify the producer revision that establishes each
rule. Include an accepted boundary case beside the rejected case so a stricter
parser cannot pass by refusing both. Keep source-derived behavior, synthetic
fixtures, and executed producer or runtime oracles distinct in validation
reports. A fixture accepted by REA proves its reader behavior; it does not prove
that a real loader accepts the artifact. If multiple producer revisions share a
format identifier but differ in behavior, record that ambiguity rather than
using one installed version as an oracle for all of them.

### Boundary regressions

For parser, inventory, snapshot, or projection fixes, select the applicable
cases below. Assert the producing boundary's facts and their meaning in affected
consumers. Add [lifecycle regressions](#lifecycle-regressions) when resource
ownership or finalization changes; a single malformed fixture cannot establish
the whole contract.

When consolidating interpretation across consumers, use the same authored
input and an independently specified expected fact at the boundary where
each consumer previously made its own decision. Allow differences in
recovery or display when those belong to the consumer. For generated
installers and verifiers, exercise the emitted artifact in its supported
runtime so the test covers the code that actually receives the input.

When detection and detailed inspection share a reader, compare a valid
input, a recognizable malformed input, and a valid input whose examined
prefix ends at the budget when those cases apply. Assert the recognized
format, which fields are established, and the coverage and diagnostics in
each consumer. If the source feeds both a digest and a converter, exercise a
change to the original between the snapshot read and conversion. Assert that
the digest and converted value describe the same bytes, or that the operation
returns a typed failure. Check advertised effects and the lifecycle of any
temporary copy.

| Failure class                         | Regression that catches it                                                                                                                                                                                                                                                                                                                         |
| ------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Format assumptions                    | Pair valid padding, offsets, or names containing delimiters with malformed input. Identify the producer revision when behavior varies by version; an unrelated runtime API's range is not an on-disk format limit.                                                                                                                                 |
| Raw identity and normalization        | Exercise allowed empty or unusual source names/metadata keys and values that normalize to one lookup or display value. Preserve admitted raw spelling under the existing redactions for transport credentials and explicitly marked sensitive values. Distinguish local paths, file URLs and HTTP paths; assert source identity through consumers. |
| Missing, empty, and unknown values    | Distinguish omitted, null, empty, zero, and false where the format admits them. Pair a malformed optional field with usable sibling facts; assert uncertainty without inventing absence or discarding the row.                                                                                                                                     |
| Completed work followed by failure    | Complete one input, then fail or cancel a later input. Assert earlier digests, metadata, and parsed facts survive with the later failure reason and accurate processed/unprocessed coverage. For cancellation, assert the exact caller abort reason; where a primary failure was already produced, assert it survives.                             |
| Independent limits and failures       | Trigger a sample/output limit alongside a read or parse failure. Assert both dimensions survive; reaching a limit does not erase sampling failures or prove complete coverage.                                                                                                                                                                     |
| Representation expansion and capacity | Keep a valid set near the limit and a large malformed input followed by a valid input. Cover JSON escaping, expanded paths or decoded rows as applicable. Assert serialized bounds, retained identities, later valid results, and unknown omissions without charging discarded interpretations as retained output.                                 |
| Snapshots, caches, and comparison     | Vary metadata that affects the result while keeping payload bytes equal. Exercise historical records with newly introduced fields omitted, current caller inputs on replay, and reuse across differing selections. Assert correct invalidation or unknown coverage, current request provenance, and unchanged saved Evidence and IDs.              |
| Public success and error delivery     | Exercise affected public CLI/MCP paths, including partial Evidence on failure. Assert retained facts and named contracts; retrieve partial Evidence when MCP returns a reference. If SDK cancellation suppresses the reply, check server settlement and any retained Evidence. An error-code assertion alone misses lost observations.             |

For partial Evidence delivery, verify that same-session readback preserves
identity and provenance without rerunning the provider. Include a no-writer
control that keeps completed Evidence inline and preserves the original failure.

For a seekable file with a known extent, distinguish a provably impossible wire
extent from an independent representation limit. Pair the malformed declaration
with a structurally possible over-limit control. Include a length that fits the
remaining bytes by itself but would consume the framing required for a later
field or row. A count-only truncated fixture does not establish capacity
behavior. This does not require decoding an opaque compressed payload merely
to apply its declared expansion limit.

When producer order is unspecified, synchronize fixtures on the observed request
or completion event. A filename, generated key, or fixed delay does not prove
which item completed before cancellation. Preserve real producer ordering and
use a controlled seam for the phase that needs deterministic failure.

Packed bridge validation uses Python's standard-library AST and tar readers
with `-I -S`: caller-local modules, `PYTHONPATH`, and site startup hooks must
not replace those readers or execute during validation. Controlled `ast.py`
and `sitecustomize.py` fixtures must leave their markers absent and still
reject malformed packed Python with `SyntaxError`. This checks static package
verification, not real Hopper or Ghidra behavior.

Stateless source-analysis matrices may share a file-owned stdio MCP connection
and retain representative compiled CLI parity checks. Every distinct source
scenario still runs through the public workflow; session-lifecycle scenarios
need their own sessions and cleanup assertions.

Complete-inline-Evidence conformance uses
`scripts/lib/mcp-verification-environment.mjs`: a finite 65,536-element
allowance selected by the application harness, file-owned CLI/MCP session and
artifact verifiers.
Explicit harness environment selections take precedence. This keeps canonical
workflow assertions reachable for large retained observations. Admission-policy
tests launch the public server with the resource setting unset or explicitly
selected, including the default structured-input boundary and continued-service
checks. Downstream capacity fixtures select enough finite transport allowance
to reach their original memory, depth, cycle or representation boundary; retain
those stronger assertions.

When a matrix already holds a named tool definition from live `tools/list`,
pass that definition through the SDK's `toolDefinition` call option, with the
canonical output schema attached (`tools/list` omits output schemas by default).
This keeps output-schema validation without eagerly compiling unrelated catalog
schemas. Re-read definitions if the server advertises a changed list.

For exact nested input constraints, assert the canonical input schema
(`advertisedInputJsonSchema`) or use the full-SDK conformance suite that owns
the field. Compact workflow tests
should assert canonical failure categories and provider-call controls where
rejection before provider work matters. Do not make today's omission of a
constraint a compact-profile invariant.

Give every MCP SDK test client the validator from
`createMcpSchemaValidation` (or use `mcpTest`); the architecture guards count
clients that keep the SDK default. Compiled validators are shared across the
worker in a bounded cache keyed by the complete schema, and the SDK provider
keeps dialect and format validation. A fixture created inline for one client
is released with that client. When a file holds one fixture for several
clients, clear it in `afterAll`. Keep sessions and connections scoped to each
test; share immutable schema preparation through the fixture's validator
dependency.

Artifact verification uses `artifactMcpCall` for both lifecycle and analysis
calls. A fresh SDK client has no held tool listing, so a bare `callTool` can
skip output-schema validation. The helper discovers actual advertised
definitions, rejects missing or ambiguous schemas, and validates the requested
tool without compiling unrelated catalog schemas. REA registers process-static
tool contracts; bindings share one discovery per negotiated connection and are
discarded on reconnect or failed discovery. Keep raw artifact calls on this
shared path and retain explicit request options such as timeouts.
Caller-supplied tool definitions are rejected: the helper owns selection from
the advertised catalog so a stale or permissive schema cannot bypass it.

The regression fixture changes only `canonical_path` in a real stdio response
to a number. The old helper accepts that response; the named schema must reject
it. This client-boundary fault injection does not establish native Apple
behavior, which remains covered by the macOS verification lane.

Report unavailable authority as a named skip. Await owned cleanup before a
verifier reports success. Native process inspectors are released at Vitest
worker teardown; fork termination does not run Node exit hooks, and per-file
teardown would retire inspectors still needed by other files.

Measure slow cases before pruning capacity coverage. Retain inputs beyond the
formerly failing size/depth and distinguish cold runs, warm builds, coverage,
and toolchain conditions when comparing timings.

## Lifecycle regressions

Investigation lifetime changes exercise public MCP target A/B switches, target-free
close and close cleanup failure/retry, with exact retained IDs and complete Unknown
revision histories. Verify engine replay/cache removal separately from retained
facts. An explicit reset must preserve a healthy engine and existing metadata
invalidation, drain an admitted signal-ignoring late result, block later work,
and prevent stale replay/source bindings from restoring old facts. Cover checkpoint
overwrite refusal, publication followed by cancellation or staging cleanup failure,
cleanup retry, then fresh-process bundle import with identical original references
and Unknown history. Capacity admission tests preserve the complete pre-state on
failed record/import/Unknown transactions, count duplicates once, account for
metadata size deltas and release budget on reset. Controlled providers and cleanup
seams establish ordering and failure semantics; real application/provider runs are
reported separately.

Hold successful and error replies at the MCP transport boundary while reset
queues behind their original admission. Verify checkpoint contents and publication
order, including SDK output validation failure, handler failure and cancellation
before or during send. Handler cleanup must settle even when the SDK suppresses
the reply. An outgoing server request with the same numeric ID as an incoming
tool request must not acknowledge that tool's response.

For changes to resource acquisition, readiness, cancellation, or cleanup, select
the affected owners and applicable scenarios below. Include temporary snapshots
and one-shot commands. Use public CLI/MCP workflows where practical and a
controlled production seam for interleavings that cannot be reproduced reliably.

To assert that a POSIX process or process group has stopped, use
`processHasStopped` or `processGroupHasStopped` from
`tests/support/process/observePosixProcess.ts`, not signal 0. Signal 0 still
reaches a zombie, and an orphan stays one wherever PID 1 does not reap it, as in
a container started without an init process.

| Scenario                                                                                | Assertion and control                                                                                                                                                                                                                                                                     |
| --------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Target admitted; startup still pending                                                  | Status preserves the readiness distinction and observed startup activity; readiness requires the provider's documented proof.                                                                                                                                                             |
| First handshake is late, absent, invalid, or recovered during close                     | Initial and recovery paths retain the same authenticated identity facts. Foreign run/token controls cannot authorize cleanup; authenticated idle/native work survives the unauthenticated listener deadline.                                                                              |
| Launch returns an error with a valid process handle                                     | Cover already-exited and still-live owned processes. Verify observed exit separately from creation; failed termination or unavailable identity remains unresolved.                                                                                                                        |
| Cancellation arrives after workload exit, during result reads or temporary-root removal | Before the documented commit cutoff, return typed cancellation with available partial observations and actual cleanup status. After commit, assert the owning publication outcome and receipt. The non-aborted control succeeds; existing primary/cleanup failures keep their precedence. |
| Children have mixed health or cleanup outcomes                                          | Missing peer health does not erase an observed failure or activity. Idle plus unknown stays unknown. Retry a failed child without closing a successful peer again, including after a close-option change.                                                                                 |
| Cleanup fails after success or primary failure                                          | Public output retains the completed observation or primary diagnostic, remaining resources, and owner recovery action. Restore the denied resource and verify the owning cleanup retry.                                                                                                   |
| Cleanup owners recover after an error was returned                                      | Retain the original child and aggregate errors and project them after each owner releases. A successful peer stays released; the aggregate remains incomplete until all owners release. Preserve the first cause even when rejection is `undefined`.                                      |
| Target exits without an acknowledgement, or transport disappears while it stays alive   | Positive owned exit proof resolves target lifetime; other resources still need cleanup. Lost transport alone does not prove exit. Verify unrelated/attached targets survive and same-connection recovery works when supported.                                                            |

Owners that finalize through `runOwned` inherit the precedence rows above from
`src/providers/runOwned.lifecycle.test.ts`, which runs each scenario over a
table of adopter shapes (partial or diagnostics record, publication, lease).
Add a shape to that table instead of repeating those cases per provider; a
provider's own tests cover how its work and close reach `runOwned`.

Shared process-supervision controls separate leader exit from output closure.
Cover output during held or failed cleanup, bounded retention and drain timeout,
retry, and borrowed stream authority. The POSIX inherited-stderr control uses a
separate pipe as a release barrier after leader exit; it does not establish
native Windows Job Object behavior.

Synchronize cancellation with the finalization boundary being tested; a fixed
delay after dispatch does not establish that phase. Use markers, barriers, or
owned cleanup seams while preserving real cleanup where feasible.
`tests/support/lifecycleHarness.ts` provides the shared controls: `phaseGate`
holds a late handshake or in-flight work at a boundary and releases it with a
value or a rejection, `phaseArrival` marks a boundary whose work waits on
something else (an abort, another owner), `cancelDuringCleanup`
cancels from inside final cleanup, and `controlledCleanup` gives children
refused or confirmed outcomes with counted retries.
`tests/support/providerLifecycleCoverage.ts` maps every registered provider id
to its launch, handshake, operation, cancellation, cleanup and retry
regressions or a reason a stage does not apply. Name the test file and the
title at its registration site when a change adds or moves a lifecycle
regression. The check rejects uncovered applicable stages. Check server
settlement and retained resources even if the MCP SDK rejects the client promise
before the handler finishes. A cancellation during active execution does not
cover cancellation during final cleanup.
For ZIP extraction, replace the pathname after inventory reader close while the
admitted root descriptor remains owned. Verify that identical member bytes in a
different carrier, a directory, or a missing pathname cannot switch the
materialized source. Exercise descriptor close failure and retry before output
publication. Inject a producer finalization failure after its output sink
closes and verify that the consumer observes the failure. Successful EOF
requires the producer to settle successfully, even when all output bytes have
arrived.
Use explicit abort reasons and assert their identity at admission and after
provider completion, alongside retained observations and cleanup state.
Include a physical I/O failure reused as the abort reason and genuine
cancellation whose reason is already a typed error; neither error names nor
value equality establishes origin. Assert that cleanup capabilities carried by
that opaque reason are neither adopted nor released. Verify an owning command's timeout or
refusal policy when preparation records cancellation but its caller is still
active. Parallel inspection failures must retain completed observations and
mixed physical/cancelled request facts after all peers settle, including
multiple failed closes and partial cleanup retry. For input copying, hold an
admitted read or write in flight before cancelling; descriptor close and
workspace retirement must await its settlement.

Electron fuse regressions cover actual descriptor close denial and retry through
the built CLI, same-connection MCP recovery, mixed descriptor outcomes, and
server shutdown. Controlled seams cover cancellation during final close and
after reader finalization, plus active-provider shutdown during preflight.
They preserve real filesystem cleanup where possible; mocked launch boundaries
do not establish real Electron teardown or naturally occurring OS failures.

Active Electron cleanup controls retain independent transport and process-family
owners, block replacement captures until recovery, and retry only unresolved
owners. Cover late close acknowledgement and rejection after a wait deadline,
opaque rejection reasons, cancellation during failed finalization, and missing
lineage followed by a confirmed passive family census. Windows controls require
a fresh lineage observation and do not signal cached descendant PIDs after root
termination. Simulated Windows controls do not establish native Windows behavior.

Native process-ownership controls distinguish start identity, zombie lifecycle,
current parent/group relation, and token-read evidence. Retain generation-bound
candidates through smaller lineage observations, table omissions, reparenting,
group changes, and failed cleanup retries. Identityless exit-refresh controls
cover a replacement row that is not linked to the prior descendant set: a
matching token on its own group is signaled, a foreign or absent token is not,
an unreadable live token stays unresolved, a replacement that appears only in
the confirmation table is still token-checked, a group discovered during
revalidation is signaled before cleanup succeeds, a member that changes groups
during confirmation is signaled in its new group, a PID first seen with a
foreign token is read again on the confirmation table, a PID whose token was
already read is read again even when its parent and group return to the
pre-exit values, a pre-existing PID is read again when its parent or group
changes, an unchanged pre-existing row that was never token-read stays unread,
an unbounded confirmation
chain stays unresolved, lineage reads a row again when its launcher-tree
membership changes, a cached lineage token is read again on the next refresh, an initial descendant whose token already matched is read again on a later refresh, the launcher is read again on that refresh and a missing, unowned, or relation-changed launcher PID stays unavailable, a descendant absent from the latest refresh is omitted,
a group that reappears after it was processed is revalidated once, a further
reappearance stays unresolved, lineage publishes one row per PID, and lineage does not publish a
verified empty descendant list while that row remains unexamined. A readable token with unavailable
identity stays unresolved. Both the sweep and the pre-signal group check re-read
an unreadable live token a bounded number of times. The sweep classifies the
PID's current process; the pre-signal re-read stays bound to the first observed
generation, so a reused PID stays unresolved there. A token that stays
unreadable fails closed with the native name, parent, group and identity that
bracketed it. Native UID facts, rather than an earlier process-table
row, determine whether a token denial concerns another user. Darwin tests compile
the helper and exercise snapshot growth, absence, lifecycle, name and UID observations;
controlled Linux procfs tests do not establish real Linux exit or PID-reuse behavior.

For atomic writes, exercise cancellation on both sides of the documented commit
point and preserve any publication receipt. A late interruption does not prove
that no output was published.

For successful provider reports, test cancellation immediately before the report
reaches the application workflow as well as during provider cleanup. Validate
the report before classifying completion: a valid report must retain its Evidence
on cancellation, and an invalid report must keep its output error. Exercise both
the provider boundary and the shared CLI/MCP workflow; a downstream guard does
not repair the provider's own completion contract. When callers share startup,
cancel each waiter independently and verify that the last departure awaits owned
cleanup while interested peers can still reach readiness. Repeat the same
shutdown event after a cleanup failure to verify that its listener can retry.
Exercise non-default lifecycle deadlines through queued requests and their
consumers; default-only controls cannot detect dropped request options.

For descriptor-backed reads, inject a close failure after a successful read and
after a primary read or cancellation failure. Verify that the exact descriptor
remains owned, both failures survive, and a later close retries it. Repeat
admission attempts while close still fails: no additional descriptor or
native command should start. Restore close and verify that the exact owner
resolves the originating cleanup marker and allows later work, while the earlier
failure remains available as a diagnostic. Retain errors returned by multiple
failed retries, including admission and shutdown aggregates, and assert that
each becomes complete after recovery. For an aggregate with multiple owners,
release one owner while another still fails and assert that it remains incomplete.
Cover recovery before the
caller-specific error is bound to its retained owner, as
another request can retry cleanup concurrently. Confirm that an already released
owner resolves a later binding too. Include
admission failure after opening the descriptor. If caller cancellation returns
before an inspection settles, gate its final read or close and verify that
session shutdown waits for the owned work and reports any retained resources.
Gate a later read in a multi-read inspection, not only its first read. Overlap
operations so one retains a failed descriptor while another reaches its next
read; both the operation and shutdown must settle without nested-admission
deadlock. Deny child close and verify its containing root survives until retry.

Exercise publication on filesystems without hard links using an unsupported-link
seam. Check exclusive destination creation, stat/write/close failures, completed
output receipts, and cancellation at the documented cutoff. A streamed fallback
has different visibility from an atomic hard-link commit and must report it
accurately. For Windows command supervision, keep a descendant writing after its
leader exits, deny cleanup observation, and verify a competing writer remains
excluded until the exact Job Object closes. Portable doubles cover retry logic;
the native Windows lane must establish actual process-tree behavior.

Supervisor tests must observe process exit, output-pipe closure, and IPC
disconnection separately. In the pinned Node runtime, a parent-initiated IPC
disconnect can omit the aggregate `ChildProcess` close event. Join the actual
resource observations before reporting completion; process exit alone does not
establish pipe or process-tree release.

When changing an internal helper contract, check its JavaScript verifier and
subprocess-script consumers alongside TypeScript references. Source typecheck
does not check those calls; run their orchestration tests against the built
modules, including the verifier's failure and cleanup paths.

Representative regressions include
[process cleanup-time SIGINT](https://github.com/morluto/rea/blob/e78455338fe2d06c4cd03d59cbf33473d754998b/tests/boundary/process/processCaptureCancellationAdapters.test.ts),
[late authenticated cleanup](https://github.com/morluto/rea/blob/e78455338fe2d06c4cd03d59cbf33473d754998b/tests/boundary/providers/hopper/hopperClient.handshakeRecovery.test.ts),
[LLDB launch and finalization](https://github.com/morluto/rea/blob/e78455338fe2d06c4cd03d59cbf33473d754998b/tests/boundary/providers/native/lldbCallTracerFailures.test.ts),
[composed child ownership](https://github.com/morluto/rea/blob/e78455338fe2d06c4cd03d59cbf33473d754998b/src/application/binary/CompositeProvider.test.ts),
and [public CLI cleanup denial](https://github.com/morluto/rea/blob/e78455338fe2d06c4cd03d59cbf33473d754998b/tests/boundary/cli/wasmCleanupCli.test.ts).
These controlled probes do not replace the matching real-provider lane. Record
the base failure, passing control, exact host/provider, verified cleanup, and
unavailable coverage; a missing engine is not a pass.

## Behavioral depths

| Depth        | Location                | What it proves                                                                                        |
| ------------ | ----------------------- | ----------------------------------------------------------------------------------------------------- |
| Module       | `src/**/*.test.ts`      | One domain, service, or adapter through its narrow public surface                                     |
| Composition  | `tests/composition/**`  | Provider-neutral session and registry wiring; filesystem access is limited to fixture materialization |
| Boundary     | `tests/boundary/**`     | Exactly one production filesystem, process, network, browser, CLI, or provider boundary               |
| MCP boundary | `tests/boundary/mcp/**` | MCP transport and tool-contract boundaries with isolated sessions and explicit cleanup                |
| Acceptance   | `tests/acceptance/**`   | A compiled CLI or MCP journey; injected providers still make it integration                           |
| Conformance  | `tests/conformance/**`  | Shared provider contracts, parameterized by declared capabilities and explicit opt-outs               |
| Evaluation   | `tests/evaluation/**`   | Deterministic evaluator parsing, scoring, and report generation                                       |

Colocated domain tests may import only their owning domain and inward
dependencies. They do not construct sessions or servers and do not start
subprocesses or network listeners. Colocated application tests exercise one
service through explicit ports and recording adapters, never a CLI or MCP
entrypoint. Composition tests may assemble provider-neutral sessions and
registries but do not cross production filesystem, process, socket, or browser boundaries.
Boundary tests cross one production boundary. Only acceptance tests assemble
the complete runtime or invoke the compiled product surface.

Focused immutable builders and recording ports shared by one test family live
beside their production owner as `src/**/*.fixture.ts`. They are typechecked
with the suite and excluded from package builds; broader runtime and provider
fixtures remain under `tests/fixtures/**`.

`tests/process-global/**` is reserved for cases with a demonstrated dependency
on process-global state. Those tests use isolated forks so environment and
exit-status changes cannot leak between files. Serialize a case only when it
demonstrably shares an external resource that cannot be isolated. Reusable,
test-scoped fixtures live under `tests/support/**`; immutable source artifacts
remain under `tests/fixtures/**`.
The process-global Vitest configuration contract rejects new direct temporary-root
creation outside the workspace seam and its narrowly documented boundary/package
exceptions.

The shared temporary-directory and workspace helpers preserve caller labels
under an owned `rea-` prefix when needed. Their
[cleanup ownership differs](https://github.com/morluto/rea/blob/main/CONTRIBUTING.md#temporary-files-and-diagnostics):
`createTestTempDirectory` registers `onTestFinished` deletion, while
`createTestWorkspace` requires caller cleanup. Close resources before removing
their directory. `npm run verify:test-temp-hygiene`
uses the same ownership rule to find retained fixtures under a private temporary
root. Third-party caches remain outside that ownership rule.

Real Hopper, Ghidra, IDA, browser, package, and managed-code claims belong to their
explicit `npm run verify:*` lanes. The reconstruction-readiness lane separates
observed native CLI inspection and JavaScript/Electron static CLI/MCP analysis
from synthetic report-evaluator conformance. Its determinism, tamper, and
stale-source checks concern the synthetic evaluator; they do not execute fixture
applications or verify runtime authority, cleanup, comparison, or reconstruction
closure. The evaluator and its semantic tests belong to
`tests/conformance/readiness/report/`, outside the shipped runtime. When
application runtime behavior is needed, exercise the actual target through
browser, Electron, or process capture. Real model trials are manual; Vitest
covers deterministic evaluator logic.

`verify:managed` runs the portable PE byte-fixture conformance entrypoint under
`scripts/verify/managed/`, with its byte builder under
`scripts/fixtures/managed/`. It checks static classification, members,
reconstruction, native-boundary relationships and application graphs without
executing fixture PE files. Operator-local manifests and actual ILSpy oracles
remain optional, separately reported checks; the real Ghidra NativeAOT lane has
its own toolchain prerequisites. See [the managed guide](../guides/managed/managed-code-analysis.md)
for those configurations. Generated completion-ledger checks use the same owning
entrypoint and include its verifier/fixture files in their cache inputs.

## End-to-end, integration and golden evidence

Prefer the public CLI or MCP workflow when it can observe the required behavior.
Use production-boundary integration for contracts the complete workflow cannot
reliably exercise, and producer goldens for format-specific facts. An acceptance
case with an injected provider verifies that integration boundary; it does not
establish real-provider behavior.

For installed-client versions, executable selectors, disposable profiles, model
fixtures, and detailed receipts, see [client verification](client-verification.md#end-to-end-integration-and-golden-evidence).
Use [real-toolchain lanes](#real-toolchain-verification-lanes) for engines and
[agent evaluation](#agent-evaluation-and-conformance-records) for investigation
quality. Report unavailable tools or authority explicitly and verify owned
cleanup before claiming success.

## Coverage and timing

CI owns coverage; aggregate and domain/contract thresholds are maintained in
`vitest.config.ts`. They are glob-specific and never updated automatically.
Coverage does not replace named boundary or real-provider scenarios.

The `reverse-tools` commands run the focused tests and report coverage and
mutation results without an additional percentage requirement. Test failures,
invalid mutation configuration, and runner failures still fail the check.
Mutation targets cover reviewed production behavior, including signal-terminated
commands, Cutter descriptor identity, debugger cleanup ownership, GDB command
exit and cancellation, and Rizin startup, timeout Evidence, and process exit.
A second exhaustive pass runs the focused Cutter and Rizin timeout semantics tests against every compilable
selected mutant to avoid relying on per-test mutation coverage associations;
Stryker reports compile-error mutants separately because those cannot execute
tests. Both passes resolve named syntax owners, scoped declarations, guards,
callbacks, and reviewed expressions from the current TypeScript source; no
hand-maintained line ranges select mutations. Missing, ambiguous, or malformed
source targets stop configuration before mutation generation. The selections
retain their review scope rather than expanding to whole source files. The
focused suite also exercises affected MCP routes and the Python Cutter bridge.
Contract, integration, and real-provider lanes complement these focused tests;
simulated providers do not establish real-provider behavior.

Required CI retains fresh reverse-tools coverage and preflights both canonical
Stryker configurations with `--dryRunOnly`. These preflights resolve the owned
targets, instrument the source, and execute the real initial tests. Invalid
configuration, target resolution, and initial test failures still fail the job.
Preflights execute no mutants and produce no mutation-outcome report. Both fast
feedback and full qualification, including exact-revision release qualification,
require coverage and both preflights. A failed, canceled, skipped or missing
selected quality job still fails the required gate.

The separate **Mutation sweep** workflow runs both complete configurations daily
and on manual dispatch, in two isolated jobs. It is a maintenance check outside
the PR and release publication gates. `ci:full` requests full regression,
coverage and provider qualification; it does not request a complete mutation
sweep. Use the Mutation sweep workflow to request that result. Targets,
checkers, concurrency, deadlines and the existing non-blocking mutation-score
threshold are unchanged. `npm run test:mutation:reverse-tools` also retains both
complete passes for local callers.

The two passes write separate JSON and HTML reports under `reports/mutation/`:
`reverse-tools` and `reverse-tools-semantics`. Required CI retains focused
coverage; the sweep retains each configuration's JSON/HTML reports separately.
Both retain available diagnostics for seven days after failure and skip uploads
on cancellation. Artifact names identify the tier or configuration and run
attempt. A successful sweep requires both jobs and their nonempty reports;
partial diagnostics and preflights do not establish complete mutation outcomes
or qualify the release revision for mutation coverage.

Fast CI starts the source-only projects after classification, independently of
build and static checks, and runs twelve built-dependent shards after the build.
Those thirteen test jobs still select every portable test. Full qualification keeps twelve
complete Vitest shards with coverage. Neither tier retries tests. Canonical
project ownership lives in `scripts/lib/test-projects.mjs`, shared by Vitest,
CI group execution, and development-test preparation. A test importing compiled
verifier code belongs to the built group even if its directory is conformance.
Source and built blobs have separate labels to prevent merge collisions.
Each test job emits a blob report; the merge job produces JUnit and JSON diagnostics, a module timing
report, plus aggregate coverage during full qualification. It retains available
reports even when a shard fails, uploads available diagnostics, and writes the
slowest files to the workflow summary. When a merged run fails, the summary
and job log also list up to 20 reported failed test files and the count of
unhandled Vitest errors when reported. Partial reports are marked diagnostic
only. Failed, cancelled, or missing selected shards still fail the required gate,
and aggregate coverage thresholds remain enforced in full qualification.
A complete shard merge on a default-branch push, schedule, or manual run can
publish timing history. Fast runs publish `test-timings-fast` and full runs
publish `test-timings-full`. The build job accepts only verified artifacts from
successful default-branch CI runs that match its tier. It lists one page of
matching artifacts and checks up to five producer runs individually. When
eligible artifacts remain, it can check them against one page of successful CI
runs. A tier with no qualifying artifact leaves history unset. The build
downloads the small, checkout-relative timing file. Timing weights come from Vitest module
diagnostics and include tests and hooks, worker preparation, environment,
imports, and setup. Import timings already include transform waits, which are
not added again. The weights describe file costs under the measured worker and
coverage settings; their sum is not workflow elapsed time. The diagnostic
artifact retains the phase breakdown, while shard history keeps only each
file's total. Legacy test-body-only history and missing history fall back to native
sharding. Static checks, documentation, build, package verification, and
real-system lanes remain separate jobs so one kind of evidence cannot stand in
for another. Workflow syntax and expression validation runs inside the required
static-check job when workflow changes select it, avoiding a separate runner.
Native, provider, fixture, SQLite compatibility, and website lanes wait for
the fast static checks (typecheck, built lint, and format) to succeed before
allocating their runners. Knip, duplication, architecture guards, test
discovery, and the Python producer run in the separate full-tier deep static
job and do not gate provider admission. On the fast tier, changes to Python
bridges, analysis-efficiency inputs, or the Python test runner select a separate
required Python job. That job installs locked dependencies and prepares the
compiled runtime before the suite, because analysis-efficiency checks import
built process modules. Bridge tests are discovered from the source tree. The
mitmproxy, native, and pwndbg families must each contain a test module and
execute at least one non-skipped case or subtest. A parent case with only skipped
subtests does not satisfy this requirement. A newly added failing test fails the job.
Portable test shards and documentation checks remain independent of static results, so they can still provide
diagnostic feedback. The required gate rejects skipped selected lanes when
static checks fail; on the full tier it also requires the deep static job.
Passing revisions retain all selected coverage. This ordering reduces peak
demand on invalid revisions but can add static-check waiting to otherwise
passing runs; it is not a measured reduction in end-to-end latency.

Core jobs have execution limits of five minutes for classification, ten minutes
for static checks, builds, docs, and report merging, and thirty minutes per
portable test shard. These limits leave headroom for cold setup and full coverage
while preventing a hung job from holding the active main run for hours. They do
not bound runner queue waiting. Timeouts still fail the required gate.

The separate `CI timings` workflow also diagnoses missing, startup-failed,
queued/running, approval-required, canceled, and failed PR CI through bounded,
read-only API scans. Incomplete pagination or changing identity stays unknown.
It never closes/reopens PRs, reruns workflows, posts comments, or changes gates.
The timing manifest retains each run's event and head branch, including explicit
unknowns, so PR runs cannot consume the eligible-main comparison budget.
Its static failure report compares supported lint/duplication diagnostics with
failed main runs using exact source, ancestry, task hashes, and toolchain proof.
A match describes those diagnostics only; it does not establish that every
failure in a job came from main. Duplication reports retain the actual checker
exit result, so passing duplication checks preserve lint failures and caller
thresholds remain owned by the producer. Missing checker outcomes leave
those duplication diagnostics unclassified. Missing historical receipts remain unknown.
The reporter executes only trusted default-branch code and parses whitelisted
JSON artifact members without executing artifact content. Reports and limits
are retained in `ci-health-diagnostics`; its ten-minute job limit covers the
existing four-minute timing collection plus the bounded diagnostic stages.

Fast built shards target under ten minutes of uncontended shard-job execution.
That figure is the `test-shard` job. The job waits for classification and the
build, and the portable-test merge runs after the slowest shard. Runner queue is
separate and grows when more shard jobs compete for runners. The npm download
cache stays the setup cache rather than a shared `node_modules` artifact.
`process-boundary` stays serial because process-tree sampling shares the host.
Hosted CI jobs use four workers; other hosts stay at two
because they are shared with other checks. Full qualification keeps twelve covered
shards; its longer instrumentation is outside this fast budget.

The separate `CI timings` workflow batches recent completed CI and Release runs
every six hours or on manual dispatch, and snapshots pull-request CI health across
the preceding twelve hours using full ISO 8601 timestamps within a ten-page
(1,000-run) API budget. It uploads `ci-job-timings-batch` with raw API pages and
a normalized point-in-time report for each collected workflow attempt, plus a
batch manifest describing examined coverage, failures, and limits. Overlapping
lookback windows may collect an attempt again; identify records by run ID and
attempt. Each batch examines at most 100 completed runs per workflow created in
the preceding 24 hours, with a four-minute API collection budget. It collects the
latest attempt of each selected run and does not claim an exhaustive archive.
It runs the reporter from the trusted default branch with read-only permissions,
treating workflow runs as API data. It does not allocate a new reporter job for
every completed, cancelled, or skipped workflow. Reports separate queue
waiting (`created_at` to `started_at`) from completed execution and report
percentiles plus matched `npm ci` and artifact-step durations.
Queue excludes dependency waiting before job creation and does not establish
whether account concurrency or runner availability caused the wait. Queued jobs with
placeholder start times, skipped jobs, and missing or invalid timestamps remain
unknown. The reporter targets each selected run and attempt explicitly.
Summed job elapsed time is parallel work, not workflow wall time, CPU time,
memory usage, or billing. Step names identify samples, not complete transfer
costs. Its queue, execution, and failures are independent of the required gate
and publication. CPU time and peak process-family memory are not measured by this API.

The build job saves portable Turbo outputs across runs. Linux real-system lanes
that pass `build_cache_artifact` reuse its current-run artifact; standalone dispatches restore the cross-run cache. The shared action
derives its key from `test:prepare --dry=json` task hashes, runner OS and
architecture, `.npmrc`, `.nvmrc`, and the lockfile; test-only changes can reuse compiled outputs. Every
build and verification command still runs, so Turbo checks task inputs and
rebuilds misses. A restore prefix with the same platform and toolchain permits
partial task reuse when one generator's inputs change; Turbo still invalidates
that generator's entry. Native outputs are not stored in this cache.

POSIX native package jobs, documentation checks, Go binary verification, and the
Apple artifact lane reuse the same workflow's portable Turbo cache
(`rea-build-cache`) for compiled JavaScript, skills, and catalogs. Windows jobs
(`windows-curated` and Windows `package-e2e`) compile with `typescript` rather
than Linux's accelerated `tsrs` checker, so they restore and publish a separate
Windows `.turbo/cache/` family (`rea-windows-build-v1-Windows-X64-*`, pruned to
two generations by `cache-retention.mjs`). `windows-native-build` caches
cross-compiled MinGW outputs keyed by source/fixture hashes, runner
`ImageOS`/`ImageVersion`, and UTC date (bounding lifetime to 24 hours so
upstream toolchain updates refresh daily) while running
`npm run verify:windows-native:artifact` unconditionally on every cache hit. The
key parser retains the validated `test:prepare` task identities in
`.cache/ci-build-plan.json`; staging reads this plan without starting another
Turbo run that could evict cache entries. The producer stages matching archives,
metadata, and available manifests into `.cache/ci-build-cache/`.
`portable-build-cache.json` records availability per task. Evicted or partially
missing entries are omitted as whole entries, and consumers rebuild cache misses,
including when every entry is unavailable. Malformed plans, non-file entries,
and I/O errors other than disappearance still fail publication. After a trusted
static run, superseded cross-run Turbo snapshots for that OS and architecture
are deleted down to the two newest generations. The Windows lane also runs the
official compiler's complete source typecheck with two checker threads,
independently of the accelerated Linux checker. Both lanes retain the normal
build and prepack commands, which restore matching outputs or rebuild on a cache
miss. Native
artifacts, dependency installs, package archives, and runtime verification remain
host-local. Keep platform-dependent outputs out of this shared cache.

The Windows native verifier's private-runtime ACL observer reads the owner and
access rules only in SID form, checks that every identity it compares is a
`SecurityIdentifier`, and never uses `Get-Acl` or the convenience `Access`
property, which resolves account names. Its Windows PowerShell observers call
.NET members directly and build their JSON without cmdlets, pipelines, module
autoloading, or type-table updates. The `private-runtime-acl` stderr markers
report the powershell.exe process uptime and each completed phase; inspect them
on a timeout before attributing it to startup, ACL reads, or identity lookup.
The 60-second observer deadline bounds a hung observer while covering a cold
powershell.exe start on a starved hosted runner. All ownership, DACL, and
readonly assertions remain in force. A passing retry alone does not explain a
previous timeout.

Record cold and warm preparation separately from fresh test execution when
benchmarking the optional `npm run check:pr` gate. Compare multiple runs on the
same host, including subprocess and queue costs; a cached pass is not a test
runtime measurement. A PR that touches packaging or real-system
behavior requires the applicable `verify:*` lanes; packaging and installation
changes also require `npm run verify:package`. The full-gate benchmark measures
that explicit lane, not the routine iteration requirement.

The package-update registry fixture retains its first proxy/body failure and
aborts the owned updater command. It joins the helper and installer descendants
before workspace removal. Incomplete process cleanup retains the exact owner
and workspace rather than reporting successful removal. The controlled
`packageUpdateRegistryFailure` regression needs built process modules, uses no
public registry, and checks both the primary failure and live descendant absence.

## Pull-request test selection

CI on a pull request runs static checks, the build and the portable tests the
change affects. The complete portable suite runs on every push to `main`, on
the scheduled and manual qualification runs, in release qualification, and on a
PR labelled `ci:full`. Those complete runs catch a consumer that selection
missed, after it has merged. Add `ci:full` to a PR when its effect reaches
further than its imports show, such as runtime registration, generated files,
subprocesses or bridges. Adding the label starts full qualification at once,
and later pushes stay on the full tier while the label remains.

`scripts/ci/test-selection.mjs` owns the selection. It reads the checked-out
revision and selects:

- changed test files;
- tests that import a changed module, directly or through test-only helpers
  (non-test modules under `tests/` and `src/**/*.fixture*.ts`). Selection never
  follows production importers transitively;
- tests beside a changed module that share its stem, or that scan their
  directory with `readdir`;
- the boundary tests of a changed leaf adapter (the owner table in the same
  file), which reach their sources through the built CLI, the MCP server or a
  fake provider process;
- tests whose text names a changed path.

Verifier scripts (`scripts/verify-*.mjs`, `scripts/verify/**/*.mjs`) and shared
script libraries (`scripts/lib/*`, when no untraced consumer imports or names
them) are traced like source modules. Changed Markdown, non-code `docs/` assets,
issue templates, `LICENSE`, and `licenses/` inventories outside `src/` and
`tests/` select only the tests that name them. Declarations, guard and layer
baselines (`scripts/verify/baselines/*.json`,
`scripts/lib/module-layers.baseline.json`), `.git-blame-ignore-revs`, Python
analysis-efficiency test scripts, and advertised-schema summaries select no
portable Vitest tests unless named by path, because static, Python, and build
jobs check them. `EXPLICIT_TEST_OWNERS` binds inputs with a known test suite the
selector cannot reach by imports or file names. These include non-module CLI
parity fixtures and the managed pointer rows integration test. Selection falls
back to the complete suite if a declared owner is missing.

The PR falls back to the complete fast suite when it cannot decide:

- a shared production boundary (`src/process/`, `src/filesystem/`,
  `src/contracts/tool*`, `src/server/createServer*`, `src/cli.ts`,
  `scripts/ci/`) changed;
- any other changed input is not traced, such as workflows, package metadata,
  build and test-runner scripts, untraced `scripts/lib/` consumers, or unmapped
  fixtures and data;
- no test is selected;
- more than 400 test files are selected;
- a selected file has no single owning test project.

A selection runs as one `Test shard (k/n)` job per group of up to 50 files, at
most eight jobs, using exact file identity (`scripts/ci/test-group.mjs selected`).
The separate `Source tests` job does not run, because the groups include the
selected source tests. The `Classify changes` summary gives the mode and its
reason.

The required checks still report on every PR and fail closed:

- `Portable tests` checks that the merged report contains exactly the selected
  files: none missing, none unplanned, no duplicates.
- `CI required` accepts a selected plan only for a fast `pull_request` run with
  code changes, and then requires `build` and every selected test group.
- A missing or malformed plan fails classification, the test group and the gate.
- A selected run never publishes timing history.

## Real-toolchain verification lanes

Use [Testing lanes and provider verification](../testing-lanes.md) to choose a
command for the host, provider, and workflow you changed. Record which lane
ran and which coverage was unavailable.

<!-- Keep fragment links from earlier versions of this page working. -->

- <a id="android-apk-analysis"></a>[Android APK analysis](../testing-lanes.md#android-apk-analysis)
- <a id="apktool-resource-decoding"></a>[Apktool resource decoding](../testing-lanes.md#apktool-resource-decoding)
- <a id="flutter-build-identification"></a>[Flutter build identification](../testing-lanes.md#flutter-build-identification)
- <a id="adb-device-acquisition"></a>[ADB device acquisition](../testing-lanes.md#adb-device-acquisition)
- <a id="optional-nativeaot-ghidra-analysis"></a>[Optional NativeAOT Ghidra analysis](../testing-lanes.md#optional-nativeaot-ghidra-analysis)
- <a id="ida-mcp-adapter"></a>[IDA MCP adapter](../testing-lanes.md#ida-mcp-adapter)
- <a id="kuna-lane"></a>[Kuna lane](../testing-lanes.md#kuna-lane)
- <a id="dos-ghidra-analysis"></a>[DOS Ghidra analysis](../testing-lanes.md#dos-ghidra-analysis)
- <a id="apple-interface-builder-archives"></a>[Apple Interface Builder archives](../testing-lanes.md#apple-interface-builder-archives)
- <a id="native-platform-baseline-in-ci"></a>[Native platform baseline in CI](../testing-lanes.md#native-platform-baseline-in-ci)
- <a id="termux-android-browser-smoke-test"></a>[Termux Android browser smoke test](../testing-lanes.md#termux-android-browser-smoke-test)
- <a id="packet-capture-analysis"></a>[Packet capture analysis](../testing-lanes.md#packet-capture-analysis)
- <a id="apple-native-metadata-and-ui"></a>[Apple native metadata and UI](../testing-lanes.md#apple-native-metadata-and-ui)
- <a id="firmware-adapters"></a>[Firmware adapters](../testing-lanes.md#firmware-adapters)
- <a id="javascript-source-recovery"></a>[JavaScript source recovery](../testing-lanes.md#javascript-source-recovery)
- <a id="captured-website-source-map-lane"></a>[Captured website source-map lane](../testing-lanes.md#captured-website-source-map-lane)
- <a id="javascript-large-output-lane"></a>[JavaScript large-output lane](../testing-lanes.md#javascript-large-output-lane)
- <a id="website-runtime-attribution-lane"></a>[Website runtime attribution lane](../testing-lanes.md#website-runtime-attribution-lane)
- <a id="offline-binary-layout"></a>[Offline binary layout](../testing-lanes.md#offline-binary-layout)
- <a id="offline-evm-interface"></a>[Offline EVM interface](../testing-lanes.md#offline-evm-interface)
- <a id="recorded-crash-evidence"></a>[Recorded crash evidence](../testing-lanes.md#recorded-crash-evidence)
- <a id="exported-environment-bundles"></a>[Exported environment bundles](../testing-lanes.md#exported-environment-bundles)
- <a id="agent-evaluation-and-conformance-records"></a>[Agent evaluation and conformance records](../testing-lanes.md#agent-evaluation-and-conformance-records)
- <a id="frida-instrumentation"></a>[Frida instrumentation](../testing-lanes.md#frida-instrumentation)
- <a id="offline-wasm-artifacts"></a>[Offline WASM artifacts](../testing-lanes.md#offline-wasm-artifacts)
